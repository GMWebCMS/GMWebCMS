<?php
class Authentification extends AppModel {
	public $useTable = 'users__twofactorauth';
}