<?php
class LoginRetry extends AppModel {
}
